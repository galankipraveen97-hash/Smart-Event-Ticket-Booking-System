SMART EVENT TICKET BOOKING SYSTEM
Core Java + JDBC + MySQL

Technologies:
- Core Java
- Java 25 LTS
- JDBC
- MySQL

No Spring, Servlets, JSP, Hibernate, JPA, REST API, React or other frameworks.

SETUP:
1. Install MySQL.
3. Open database/event_booking.sql in MySQL Workbench and run it.
4. Open src/com/eventbooking/DBConnection.java.
5. Change `user` and `password` to your MySQL credentials.
6. Install JDK 25 LTS and Maven, then compile and run from the project folder:
	`mvn compile exec:java -Dexec.mainClass=com.eventbooking.Main`

Maven downloads MySQL Connector/J from the dependency in pom.xml. Do not run
`javac` or the class directly without Maven unless the Connector/J JAR is added
to the compile and runtime classpaths.

Admin:
Username: admin
Password: admin123
