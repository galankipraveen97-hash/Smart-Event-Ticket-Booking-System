package com.eventbooking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BookingDAO {

    public void bookTicket(int customerId, int eventId, int tickets) {

        try {
            Connection con = DBConnection.getConnection();

            String check = "SELECT ticket_price, available_tickets FROM event WHERE event_id=?";
            PreparedStatement ps1 = con.prepareStatement(check);
            ps1.setInt(1, eventId);

            ResultSet rs = ps1.executeQuery();

            if (!rs.next()) {
                System.out.println("Event not found.");
                con.close();
                return;
            }

            double price = rs.getDouble("ticket_price");
            int available = rs.getInt("available_tickets");

            if (tickets <= 0 || tickets > available) {
                System.out.println("Invalid number of tickets.");
                con.close();
                return;
            }

            double amount = price * tickets;

            String insert = "INSERT INTO booking(customer_id,event_id,tickets,total_amount) VALUES(?,?,?,?)";
            PreparedStatement ps2 = con.prepareStatement(insert);

            ps2.setInt(1, customerId);
            ps2.setInt(2, eventId);
            ps2.setInt(3, tickets);
            ps2.setDouble(4, amount);

            ps2.executeUpdate();

            String update = "UPDATE event SET available_tickets=available_tickets-? WHERE event_id=?";
            PreparedStatement ps3 = con.prepareStatement(update);

            ps3.setInt(1, tickets);
            ps3.setInt(2, eventId);
            ps3.executeUpdate();

            System.out.println("Ticket booked successfully.");
            System.out.println("Total Amount: " + amount);

            con.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void viewBookings(int customerId) {

        String sql = "SELECT b.booking_id,e.event_name,b.tickets,b.total_amount,b.booking_status " +
                     "FROM booking b JOIN event e ON b.event_id=e.event_id WHERE b.customer_id=?";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, customerId);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n------------- MY BOOKINGS -------------");

            while (rs.next()) {
                System.out.println("Booking ID : " + rs.getInt("booking_id"));
                System.out.println("Event      : " + rs.getString("event_name"));
                System.out.println("Tickets    : " + rs.getInt("tickets"));
                System.out.println("Amount     : " + rs.getDouble("total_amount"));
                System.out.println("Status     : " + rs.getString("booking_status"));
                System.out.println("----------------------------------------");
            }

            con.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void cancelBooking(int bookingId, int customerId) {

        try {
            Connection con = DBConnection.getConnection();

            String find = "SELECT event_id,tickets,booking_status FROM booking WHERE booking_id=? AND customer_id=?";
            PreparedStatement ps1 = con.prepareStatement(find);

            ps1.setInt(1, bookingId);
            ps1.setInt(2, customerId);

            ResultSet rs = ps1.executeQuery();

            if (!rs.next()) {
                System.out.println("Booking not found.");
                con.close();
                return;
            }

            int eventId = rs.getInt("event_id");
            int tickets = rs.getInt("tickets");
            String status = rs.getString("booking_status");

            if (status.equals("CANCELLED")) {
                System.out.println("Booking already cancelled.");
                con.close();
                return;
            }

            String cancel = "UPDATE booking SET booking_status='CANCELLED' WHERE booking_id=?";
            PreparedStatement ps2 = con.prepareStatement(cancel);
            ps2.setInt(1, bookingId);
            ps2.executeUpdate();

            String update = "UPDATE event SET available_tickets=available_tickets+? WHERE event_id=?";
            PreparedStatement ps3 = con.prepareStatement(update);
            ps3.setInt(1, tickets);
            ps3.setInt(2, eventId);
            ps3.executeUpdate();

            System.out.println("Booking cancelled successfully.");

            con.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
