package com.eventbooking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EventDAO {

    public void viewEvents() {

        String sql = "SELECT * FROM event";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            System.out.println("\n---------------- EVENTS ----------------");

            while (rs.next()) {
                System.out.println("Event ID       : " + rs.getInt("event_id"));
                System.out.println("Event Name     : " + rs.getString("event_name"));
                System.out.println("Category       : " + rs.getString("category"));
                System.out.println("Date           : " + rs.getString("event_date"));
                System.out.println("Venue          : " + rs.getString("venue"));
                System.out.println("Ticket Price   : " + rs.getDouble("ticket_price"));
                System.out.println("Available      : " + rs.getInt("available_tickets"));
                System.out.println("------------------------------------------");
            }

            con.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void addEvent(Event e) {

        String sql = "INSERT INTO event(event_name,category,event_date,venue,ticket_price,total_tickets,available_tickets) VALUES(?,?,?,?,?,?,?)";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, e.eventName);
            ps.setString(2, e.category);
            ps.setString(3, e.eventDate);
            ps.setString(4, e.venue);
            ps.setDouble(5, e.ticketPrice);
            ps.setInt(6, e.totalTickets);
            ps.setInt(7, e.totalTickets);

            ps.executeUpdate();

            System.out.println("Event added successfully.");

            con.close();

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
