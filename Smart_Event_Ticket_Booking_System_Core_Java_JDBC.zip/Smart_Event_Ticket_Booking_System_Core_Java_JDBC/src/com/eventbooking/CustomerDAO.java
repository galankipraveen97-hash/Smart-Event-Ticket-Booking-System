package com.eventbooking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDAO {

    public int registerCustomer(Customer c) {
        String checkSql = "SELECT customer_id FROM customer WHERE email=?";
        String insertSql = "INSERT INTO customer(name,email,phone) VALUES(?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement checkPs = con.prepareStatement(checkSql)) {

            checkPs.setString(1, c.email);
            try (ResultSet rs = checkPs.executeQuery()) {
                if (rs.next()) {
                    System.out.println("This email is already registered.");
                    return 0;
                }
            }

            try (PreparedStatement ps = con.prepareStatement(insertSql, java.sql.Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, c.name);
                ps.setString(2, c.email);
                ps.setString(3, c.phone);

                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Registration failed: " + e.getMessage());
        }

        return 0;
    }

    public Customer loginCustomer(String email, String phone) {
        String sql = "SELECT customer_id, name, email, phone FROM customer WHERE email=? AND phone=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, phone);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Customer(
                            rs.getInt("customer_id"),
                            rs.getString("name"),
                            rs.getString("email"),
                            rs.getString("phone")
                    );
                }
            }
        } catch (Exception e) {
            System.out.println("Login failed: " + e.getMessage());
        }

        return null;
    }
}
