package com.eventbooking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    static String url = "jdbc:mysql://localhost:3306/smart_event_booking";
    static String user = "root";
    static String password = "**********"; // CHANGE THIS

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC driver is missing from the classpath.", e);
        }

        return DriverManager.getConnection(url, user, password);
    }
}
