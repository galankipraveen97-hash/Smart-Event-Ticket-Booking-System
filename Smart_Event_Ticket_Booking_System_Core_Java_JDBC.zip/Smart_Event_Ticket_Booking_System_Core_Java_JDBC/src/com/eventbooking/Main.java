package com.eventbooking;

import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    static EventDAO eventDAO = new EventDAO();
    static CustomerDAO customerDAO = new CustomerDAO();
    static BookingDAO bookingDAO = new BookingDAO();

    public static void main(String[] args) {

        while (true) {

            System.out.println("\n====================================");
            System.out.println(" SMART EVENT TICKET BOOKING SYSTEM");
            System.out.println("====================================");
            System.out.println("1. Customer");
            System.out.println("2. Admin");
            System.out.println("3. Exit");

            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(sc.nextLine());

            if (choice == 1) {
                customerMenu();
            } else if (choice == 2) {
                adminLogin();
            } else if (choice == 3) {
                System.out.println("Thank you!");
                break;
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    static void customerMenu() {

        while (true) {
            System.out.println("\n--- CUSTOMER SECTION ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Back");

            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(sc.nextLine());

            if (choice == 1) {
                registerCustomer();
                return;
            } else if (choice == 2) {
                loginCustomer();
                return;
            } else if (choice == 3) {
                return;
            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    static void registerCustomer() {
        System.out.println("\n--- CUSTOMER REGISTRATION ---");

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        Customer c = new Customer(0, name, email, phone);
        int customerId = customerDAO.registerCustomer(c);

        if (customerId == 0) {
            System.out.println("Registration failed.");
            return;
        }

        System.out.println("Registration successful. Customer ID: " + customerId);
        customerDashboard(customerId);
    }

    static void loginCustomer() {
        System.out.println("\n--- CUSTOMER LOGIN ---");

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Phone: ");
        String phone = sc.nextLine();

        Customer customer = customerDAO.loginCustomer(email, phone);

        if (customer == null) {
            System.out.println("Invalid email or phone. Please register first.");
            return;
        }

        System.out.println("Login successful. Welcome, " + customer.name + "!");
        customerDashboard(customer.customerId);
    }

    static void customerDashboard(int customerId) {
        while (true) {

            System.out.println("\n--- CUSTOMER MENU ---");
            System.out.println("1. View Events");
            System.out.println("2. Book Ticket");
            System.out.println("3. View My Bookings");
            System.out.println("4. Cancel Booking");
            System.out.println("5. Logout");

            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(sc.nextLine());

            if (choice == 1) {
                eventDAO.viewEvents();

            } else if (choice == 2) {

                eventDAO.viewEvents();

                System.out.print("Event ID: ");
                int eventId = Integer.parseInt(sc.nextLine());

                System.out.print("Number of tickets: ");
                int tickets = Integer.parseInt(sc.nextLine());

                bookingDAO.bookTicket(customerId, eventId, tickets);

            } else if (choice == 3) {

                bookingDAO.viewBookings(customerId);

            } else if (choice == 4) {

                System.out.print("Booking ID: ");
                int bookingId = Integer.parseInt(sc.nextLine());

                bookingDAO.cancelBooking(bookingId, customerId);

            } else if (choice == 5) {
                break;

            } else {
                System.out.println("Invalid choice.");
            }
        }
    }

    static void adminLogin() {

        System.out.print("Username: ");
        String username = sc.nextLine();

        System.out.print("Password: ");
        String password = sc.nextLine();

        if (!username.equals("admin") || !password.equals("admin123")) {
            System.out.println("Invalid login.");
            return;
        }

        while (true) {

            System.out.println("\n--- ADMIN MENU ---");
            System.out.println("1. Add Event");
            System.out.println("2. View Events");
            System.out.println("3. Logout");

            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(sc.nextLine());

            if (choice == 1) {

                System.out.print("Event Name: ");
                String name = sc.nextLine();

                System.out.print("Category: ");
                String category = sc.nextLine();

                System.out.print("Event Date (YYYY-MM-DD): ");
                String date = sc.nextLine();

                System.out.print("Venue: ");
                String venue = sc.nextLine();

                System.out.print("Ticket Price: ");
                double price = Double.parseDouble(sc.nextLine());

                System.out.print("Total Tickets: ");
                int total = Integer.parseInt(sc.nextLine());

                Event e = new Event(0, name, category, date, venue,
                        price, total, total);

                eventDAO.addEvent(e);

            } else if (choice == 2) {

                eventDAO.viewEvents();

            } else if (choice == 3) {
                break;

            } else {
                System.out.println("Invalid choice.");
            }
        }
    }
}
