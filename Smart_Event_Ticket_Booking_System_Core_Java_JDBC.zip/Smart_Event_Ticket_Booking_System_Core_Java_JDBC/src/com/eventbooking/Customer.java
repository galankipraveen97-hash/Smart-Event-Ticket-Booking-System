package com.eventbooking;

public class Customer {

    int customerId;
    String name;
    String email;
    String phone;

    public Customer(int customerId, String name, String email, String phone) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }
}
