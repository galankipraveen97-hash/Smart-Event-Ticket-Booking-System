package com.eventbooking;

public class Event {

    int eventId;
    String eventName;
    String category;
    String eventDate;
    String venue;
    double ticketPrice;
    int totalTickets;
    int availableTickets;

    public Event(int eventId, String eventName, String category,
                 String eventDate, String venue, double ticketPrice,
                 int totalTickets, int availableTickets) {

        this.eventId = eventId;
        this.eventName = eventName;
        this.category = category;
        this.eventDate = eventDate;
        this.venue = venue;
        this.ticketPrice = ticketPrice;
        this.totalTickets = totalTickets;
        this.availableTickets = availableTickets;
    }
}
